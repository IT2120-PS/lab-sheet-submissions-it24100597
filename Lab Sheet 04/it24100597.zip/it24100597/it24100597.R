setwd("C:\\Users\\it24100597\\Desktop\\it24100597")
getwd()

branch_data<-read.table("Exercise.txt",header =TRUE,sep=",")

boxplot(branch_data$Sales_X1,main="Boxplot for Sales",ylab="Sales",col="lightblue",horizontal = FALSE)


print(summary(branch_data$Advertising_X2))

IQR(branch_data$Advertising_X2)

find_outliers<-function(x){
  Q1<-quantile(x,0.25)
  Q3<-quantile(x,0.75)
  IQR_val<-Q3-Q1
  ub<-Q3+1.5*IQR_val
  lb<-Q1-1.5*IQR_val
  
  outiers<-x[x<  lb|x>ub]
  if(length(outiers)==0){
    return("no outlieres ")
  }else{
    return(sort(outiers))
  }
}

years_outliers<-find_outliers(branch_data$years)
print(paste(paste(years_outliers,collapse = ",")))





